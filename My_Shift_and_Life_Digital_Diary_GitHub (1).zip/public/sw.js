/* Offline app files only. Diary data and attachment bytes stay in browser storage. */
'use strict';
const CACHE = 'shift-life-shell-v2';
const FILES = ['index.html', 'styles.css', 'task-desk.js', 'core.js', 'device-db.js',
  'task-desk-import.js', 'storage.js', 'expenses.js', 'workbook.js', 'app.js',
  'icon.svg', 'icon-192.png', 'icon-512.png', 'manifest.webmanifest'];
const urls = FILES.map(name => new URL(name, self.registration.scope).href);
const scopeUrl = new URL(self.registration.scope);

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(urls.map(url => new Request(url, { cache: 'reload' })))));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys
    .filter(key => key.startsWith('shift-life-shell-') && key !== CACHE)
    .map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('message', event => {
  if (event.data === 'activate-update') self.skipWaiting();
});
self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET' || !request.url.startsWith(self.registration.scope)) return;
  const url = new URL(request.url);
  url.search = '';
  if (request.mode === 'navigate') {
    if (url.pathname !== scopeUrl.pathname && url.href !== urls[0]) return;
    event.respondWith(caches.match(urls[0], { cacheName: CACHE }).then(cached => cached || fetch(request)));
  } else if (urls.includes(url.href)) {
    event.respondWith(caches.match(url.href, { cacheName: CACHE }).then(cached => cached || fetch(request)));
  }
});
