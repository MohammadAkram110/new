/* PKR transactions and monthly budgets. All amounts are integer paisa. */
(function (D) {
  'use strict';
  const defaults = ['Bills', 'Family', 'Groceries', 'Health', 'Meals', 'Other', 'Transport', 'Salary'];
  const types = { expense: 'Expense', income: 'Income' };
  const amount = D.formatMoney;
  const amountField = minor => minor == null ? '' : (minor / 100).toFixed(2);

  D.createExpenses = function (ui) {
    const { state, current, now, E, btn, ibtn, chip, empty, page, panel, dateNav, select, input, textarea,
      dateInput, readDate, openDialog, render, commit, ask, removeRecord, download } = ui;

    const month = () => state.date.slice(0, 7);
    const monthLabel = key => D.MONTHS[Number(key.slice(-2)) - 1] + ' ' + key.slice(0, 4);

    function categories() {
      const data = current();
      const items = new Map(defaults.map(name => [D.categoryKey(name), name]));
      for (const row of [...data.money, ...data.budgets]) if (row.category && !row.deletedAt) {
        items.set(D.categoryKey(row.category), row.category);
      }
      return [...items.values()].sort((a, b) => a.localeCompare(b));
    }

    function categoryField(value) {
      return input('category', 'Category', value, { placeholder: 'Choose or type a category',
        extra: ' list="expense-categories" maxlength="80"' }) + '<datalist id="expense-categories">' +
        categories().map(label => '<option value="' + E(label) + '"></option>').join('') + '</datalist>';
    }

    function stats(summary) {
      const values = [
        ['Spent', amount(summary.expense), ''],
        ['Income', amount(summary.income), ''],
        ['Net income', amount(summary.net), summary.net < 0 ? 'warn' : ''],
        ['Budget remaining', summary.remaining == null ? 'Set a budget' : amount(summary.remaining), summary.remaining < 0 ? 'warn' : '']
      ];
      return '<div class="metric-strip money-metrics">' + values.map(([label, value, mood]) => '<div class="metric ' + mood +
        '"><span>' + E(label) + '</span><strong>' + E(value) + '</strong></div>').join('') + '</div>';
    }

    function categoryRows(summary, editable = false) {
      const money = value => value === null ? '—' : amount(value);
      if (!summary.categories.length) return empty('No category spending or category budgets this month.');
      return '<div class="table-wrap"><table><thead><tr><th scope="col">Category</th><th scope="col">Spent</th>' +
        '<th scope="col">Budget</th><th scope="col">Remaining</th>' + (editable ? '<th scope="col">Edit budget</th>' : '') +
        '</tr></thead><tbody>' + summary.categories.map(row => {
          const cap = row.budget?.amountMinor ?? null;
          const left = cap === null ? null : cap - row.spent;
          return '<tr><th scope="row">' + E(row.name) + '</th><td>' + E(amount(row.spent)) + '</td><td>' +
            E(money(cap)) + '</td><td class="' + (left < 0 ? 'over-budget' : '') + '">' + E(money(left)) + '</td>' +
            (editable ? '<td>' + ibtn(row.budget ? 'edit' : 'plus', (row.budget ? 'Edit ' : 'Set ') + row.name + ' budget',
              'budget-edit', { id: row.budget?.id ?? '', category: row.name }) + '</td>' : '') + '</tr>';
        }).join('') + '</tbody></table></div>';
    }

    function filter(summary) {
      const query = D.tidy(state.moneyQuery).toLocaleLowerCase('en');
      return summary.records.filter(row => (!state.moneyType || row.type === state.moneyType) &&
        (!state.moneyCategory || D.categoryKey(row.category) === state.moneyCategory) &&
        (!query || [row.title, row.category, row.note].join(' ').toLocaleLowerCase('en').includes(query)))
        .sort((a, b) => b.date.localeCompare(a.date) || D.str(b.createdAt).localeCompare(D.str(a.createdAt)));
    }

    function expensePage() {
      const summary = D.financeMonth(current(), month());
      const rows = filter(summary);
      const total = summary.budget ? '<p>Monthly budget <strong>' + E(amount(summary.budget.amountMinor)) +
        '</strong></p>' : '<p class="muted">Set a monthly limit or budgets for individual categories.</p>';
      const tools = btn('Add expense', 'money-edit', {}, { cls: 'primary', icon: 'plus' }) + dateNav();
      const fields = select('moneyType', 'Type', { '': 'All types', ...types }, state.moneyType) +
        select('moneyCategory', 'Category', { '': 'All categories', ...Object.fromEntries(categories().map(name =>
          [D.categoryKey(name), name])) }, state.moneyCategory) +
        input('moneyQuery', 'Search', state.moneyQuery, { placeholder: 'Description or note' });
      const list = rows.length ? '<div class="rows">' + rows.map(row => '<div class="row money-row"><div class="row-main">' +
        btn(row.title || row.category, 'money-edit', { id: row.id }, { cls: 'row-title' }) +
        '<div class="pills">' + chip(types[row.type], row.type === 'income' ? 'green' : '') + chip(row.category) +
        chip(D.formatDate(row.date)) + '</div>' + (row.note ? '<p class="row-body">' + E(row.note) + '</p>' : '') +
        '</div><strong>' + E((row.type === 'expense' ? '−' : '+') + amount(row.amountMinor)) + '</strong></div>').join('') +
        '</div>' : empty('No transactions match this view.');
      return page('PERSONAL FINANCES', 'Expenses & Budget', monthLabel(month()) + ' · Pakistani rupees', tools) + stats(summary) +
        '<div class="split"><div class="stack">' + panel('Transactions', '<form id="money-filter-form" class="toolbar-filter">' +
          fields + '<button type="submit">Apply filters</button>' + btn('Clear', 'money-clear', {}, { cls: 'text-button' }) +
          '</form>' + list, btn('Export CSV', 'money-export', {}, { icon: 'download', cls: 'text-button' }), 'Month totals include all transactions.') +
        '</div><div class="stack">' + panel('Spending by category', total + categoryRows(summary, true),
          btn('Set budget', 'budget-edit', { id: summary.budget?.id ?? '' }, { cls: 'text-button', icon: 'plus' })) +
        '</div></div>';
    }

    function expenseEdit(id, kind, date) {
      const row = id && D.byId(current().money, id);
      if (id && (!row || row.deletedAt)) throw new Error('This transaction is in Deleted items.');
      const fields = select('type', 'Type', types, row?.type || kind || 'expense') +
        input('amount', 'Amount (PKR)', amountField(row?.amountMinor), { placeholder: '0.00', extra: ' inputmode="decimal" data-initial-focus' }) +
        categoryField(row?.category) + dateInput('date', 'Date', row?.date || date || (state.view === 'finance' ? state.date : now().date)) +
        input('title', 'Description (optional)', row?.title, { wide: true, extra: ' maxlength="160"' }) +
        textarea('note', 'Note (optional)', row?.note);
      openDialog('money', row ? 'Edit transaction' : 'Add expense or income', '<form id="money-form" class="form-grid" novalidate>' +
        fields + '</form>', (row ? btn('Delete', 'money-delete', { id }, { cls: 'danger' }) : btn('Cancel', 'close-dialog')) +
        '<button type="submit" form="money-form" class="primary">Save transaction</button>', { row });
    }

    function budgetEdit(id, category = '') {
      const selected = id ? D.byId(current().budgets, id) : current().budgets.find(row => !row.deletedAt &&
        row.month === month() && D.categoryKey(row.category) === D.categoryKey(category));
      if (id && (!selected || selected.deletedAt)) throw new Error('This budget is in Deleted items.');
      const fields = dateInput('date', 'Month (pick a date in it)', (selected?.month || month()) + '-01') +
        input('amount', 'Budget (PKR)', amountField(selected?.amountMinor), { placeholder: '0.00', extra: ' inputmode="decimal" data-initial-focus' }) +
        categoryField(selected?.category || category) +
        '<p class="muted wide">Leave Category empty for a total monthly budget.</p>';
      openDialog('budget', selected ? 'Edit monthly budget' : 'Set monthly budget',
        '<form id="budget-form" class="form-grid" novalidate>' + fields + '</form>',
        (selected ? btn('Delete', 'budget-delete', { id: selected.id }, { cls: 'danger' }) : btn('Cancel', 'close-dialog')) +
        '<button type="submit" form="budget-form" class="primary">Save budget</button>', { row: selected });
    }

    async function save(form, previous, budget) {
      const values = new FormData(form);
      const minor = D.parseMoney(values.get('amount'));
      if (minor === null) throw new Error('Enter a positive PKR amount with up to two decimal places.');
      const date = readDate(values, 'date', budget ? 'a date in the budget month' : 'the transaction date', true);
      const category = D.tidy(values.get('category'));
      if (!budget && !category) throw new Error('Choose or type a category.');
      const table = budget ? 'budgets' : 'money';
      const at = D.stamp();
      const id = previous?.id || D.uid();
      const row = { ...previous, id, amountMinor: minor, category, createdAt: previous?.createdAt || at, updatedAt: at, editToken: D.uid() };
      if (budget) row.month = date.slice(0, 7);
      else Object.assign(row, { date, type: values.get('type'), title: D.tidy(values.get('title')), note: D.str(values.get('note')) });
      await commit(data => {
        const existing = D.byId(data[table], id);
        if (previous && (!existing || existing.deletedAt || existing.editToken !== previous.editToken)) {
          throw new Error('This record changed in another tab. Reopen it to make your changes.');
        }
        if (budget && data.budgets.some(item => !item.deletedAt && item.month === row.month &&
          !D.same(item.id, id) && D.categoryKey(item.category) === D.categoryKey(category))) {
          throw new Error('This month already has a budget for that category. Open it to edit its amount.');
        }
        if (existing) data[table][data[table].indexOf(existing)] = row;
        else data[table].push(row);
      }, budget ? 'Budget saved.' : 'Transaction saved.');
    }

    function csvText(value) {
      const text = D.str(value);
      return '"' + (/^[\s]*[=+\-@]|^[\t\r\n]/.test(text) ? "'" : '') + text.replace(/"/g, '""') + '"';
    }

    function exportMonth() {
      const summary = D.financeMonth(current(), month());
      const rows = filter(summary);
      const csv = [['Date', 'Type', 'Category', 'Description', 'Note', 'Currency', 'Amount'],
        ...rows.map(row => [D.formatDate(row.date), types[row.type], row.category, row.title, row.note, 'PKR', amountField(row.amountMinor)])];
      download('\ufeff' + csv.map(row => row.map(csvText).join(',')).join('\r\n') + '\r\n',
        'Expenses_' + monthLabel(month()).replace(' ', '-') + '.csv', 'text/csv;charset=utf-8');
    }

    const deletion = (id, table, label) => ask('Move ' + label + ' to Deleted items?',
      'You can recover it in Settings & Backups.', 'Move to Deleted items', () => removeRecord(table, id));

    function review(key) {
      const summary = D.financeMonth(current(), key);
      return panel('Expenses · ' + monthLabel(key), '<p class="muted">Spent ' + E(amount(summary.expense)) +
        ' · Income ' + E(amount(summary.income)) + (summary.remaining == null ? '' : ' · Budget remaining ' + E(amount(summary.remaining))) +
        '</p>' + categoryRows(summary), btn('Expenses', 'navigate', { view: 'finance', date: key + '-01' }, { cls: 'text-button' }));
    }

    return {
      page: expensePage, save, review,
      filter(form) {
        const values = new FormData(form);
        for (const key of ['moneyType', 'moneyCategory', 'moneyQuery']) state[key] = D.tidy(values.get(key));
        render();
      },
      actions: {
        'money-edit': data => expenseEdit(data.id, data.kind, data.date),
        'budget-edit': data => budgetEdit(data.id, data.category),
        'money-delete': data => deletion(data.id, 'money', 'transaction'),
        'budget-delete': data => deletion(data.id, 'budgets', 'budget'),
        'money-clear': () => { state.moneyType = state.moneyCategory = state.moneyQuery = ''; render(); },
        'money-export': exportMonth
      }
    };
  };
})(Diary);
