/* Run with Node and Playwright. The app itself has no dependencies. */
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const { spawn } = require('node:child_process');
const { existsSync } = require('node:fs');
const legacyFixture = require('./legacy-fixture.cjs');
const path = require('node:path');
const os = require('node:os');
const { chromium } = require(process.env.DIARY_PLAYWRIGHT || 'playwright');
const project = path.resolve(__dirname, '..');
const source = existsSync(path.join(project, 'public', 'index.html')) ? 'public' : 'diary';
const time = new Date('2026-10-31T20:15:00Z');
const fixture = Buffer.from([0, 255, 4, 16, 72, 109, 195, 128]);
const port = process.env.DIARY_TEST_PORT || '8000';
const origin = 'http://127.0.0.1:' + port + '/';
const launch = {
  ...(process.env.DIARY_CHROMIUM ? { executablePath: process.env.DIARY_CHROMIUM } : {}),
  args: ['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu']
};

async function server() {
  const process = spawn('python3', ['-m', 'http.server', port, '--bind', '127.0.0.1', '--directory', source], { cwd: project, stdio: 'ignore' });
  for (let i = 0; i < 100; i += 1) {
    try {
      const response = await fetch(origin);
      if (response.ok && (await response.text()).includes('My Shift &amp; Life Digital Diary') && process.exitCode === null) return process;
    } catch { /* Wait for the documented static server. */ }
    await new Promise(resolve => setTimeout(resolve, 80));
  }
  process.kill();
  throw new Error('The Python static server did not start. Check port ' + port + '.');
}

const button = (page, name) => page.getByRole('button', { name, exact: true });
const field = (page, name) => page.locator('#dialog form [name="' + name + '"]');
const record = (data, title) => data.entries.find(row => row.title === title);
const stored = (page) => page.evaluate(() => Diary.storage.read());

async function close(page) {
  await button(page, 'Close dialog').click();
  await page.locator('#dialog').waitFor({ state: 'hidden' });
}

async function nav(page, label, touch = false) {
  if (touch) await button(page, 'Menu').tap();
  const link = page.getByRole('link', { name: label, exact: true });
  if (touch) await link.tap(); else await link.click();
}

async function openEntry(page, type, title) {
  await button(page, 'Add Entry').click();
  await button(page, type).click();
  await field(page, 'title').fill(title);
}

async function saveEntry(page) {
  await button(page, 'Save entry').click();
  await page.locator('#dialog').waitFor({ state: 'hidden' });
}

async function download(page, name, file) {
  const result = page.waitForEvent('download');
  await button(page, name).click();
  const item = await result;
  await item.saveAs(file);
  return fs.readFile(file);
}

async function restore(page, name, mode = 'Merge records') {
  await page.locator('#restore-file').setInputFiles(name);
  await page.getByRole('heading', { name: 'Preview restore', exact: true }).waitFor();
  await button(page, mode).click();
  if (mode === 'Replace diary') await button(page, 'Replace with backup').click();
  await page.locator('#dialog').waitFor({ state: 'hidden' });
}

async function setDuty(page, date, shift) {
  await button(page, 'Edit duty').click();
  await field(page, 'date').fill(date);
  await field(page, 'shift').selectOption(shift);
  await field(page, 'group').fill('Test group');
  await button(page, 'Save duty').click();
  await page.locator('#dialog').waitFor({ state: 'hidden' });
}

async function movePointer(page, handle, x, y) {
  const from = await handle.boundingBox();
  assert.ok(from, 'drag handle is visible');
  await page.mouse.move(from.x + from.width / 2, from.y + from.height / 2);
  await page.mouse.down();
  await page.mouse.move(x, y, { steps: 12 });
  await page.mouse.up();
}

async function moveTouch(session, from, x, y) {
  const start = { x: from.x + from.width / 2, y: from.y + from.height / 2 };
  await session.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [start] });
  for (let i = 1; i <= 10; i += 1) {
    await session.send('Input.dispatchTouchEvent', { type: 'touchMove',
      touchPoints: [{ x: start.x + (x - start.x) * i / 10, y: start.y + (y - start.y) * i / 10 }] });
  }
  await session.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
}

async function run() {
  const output = process.env.DIARY_TEST_OUTPUT || await fs.mkdtemp(path.join(os.tmpdir(), 'shift-life-test-'));
  await fs.mkdir(output, { recursive: true });
  const host = await server();
  let browser;
  const errors = [];
  try {
    browser = await chromium.launch(launch);
    const desktop = await browser.newContext({ viewport: { width: 1366, height: 880 }, acceptDownloads: true, timezoneId: 'America/Los_Angeles' });
    await desktop.grantPermissions(['clipboard-read', 'clipboard-write', 'notifications'], { origin });
    async function open(context) {
      const page = await context.newPage();
      page.setDefaultTimeout(20000);
      page.setDefaultNavigationTimeout(45000);
      page.on('pageerror', error => errors.push(error.message));
      page.on('console', message => {
        if (message.type() === 'error' && /Content Security Policy/.test(message.text())) errors.push(message.text());
      });
      await page.clock.setFixedTime(time);
      await page.goto(origin);
      await page.getByRole('heading', { name: '01-Nov-2026', exact: true }).waitFor();
      return page;
    }
    const page = await open(desktop);
    await nav(page, 'Shift Desk');
    await setDuty(page, '31-Oct-2026', 'Night');
    await setDuty(page, '01-Nov-2026', 'Evening');
    await nav(page, 'Today');
    await page.locator('.duty-card').getByRole('heading', { name: 'Night' }).waitFor();
    assert.match(await page.locator('.duty-card').textContent(), /Started 31-Oct-2026/);
    await page.locator('.next-card').getByRole('heading', { name: 'Evening' }).waitFor();
    await nav(page, 'Shift Desk');
    await button(page, 'During Shift').click();
    await button(page, 'Add shift log').click();
    assert.equal(await field(page, 'date').inputValue(), '01-Nov-2026');
    assert.equal(await field(page, 'dutyDate').inputValue(), '31-Oct-2026');
    await field(page, 'title').fill('Test night log');
    await field(page, 'area').fill('Test area');
    await field(page, 'equipment').fill('DEMO-1');
    await field(page, 'body').fill('Test observation wording');
    await field(page, 'readings').fill('Synthetic reading 4.5 barg');
    await saveEntry(page);
    await button(page, 'Start report').click();
    await page.getByLabel(/Test night log/).check();
    await button(page, 'Add selected').click();
    await page.getByLabel(/Test night log/).check();
    await button(page, 'Add selected').click();
    assert.equal((await field(page, 'plant1').inputValue()).match(/Test night log/g).length, 1);
    await button(page, 'Mark Ready').click();
    await page.getByRole('alert').filter({ hasText: 'Check the review box' }).waitFor();
    await field(page, 'verbal').fill('Test verbal summary');
    await field(page, 'recipient').fill('Test recipient');
    await field(page, 'reviewed').check();
    await button(page, 'Mark Ready').click();
    await page.getByRole('heading', { name: 'Shift report · Night' }).waitFor();
    const report = await download(page, 'Text export', path.join(output, 'test-report.txt'));
    assert.match(report.toString(), /31-Oct-2026 · Night/);
    assert.match(report.toString(), /Synthetic reading 4.5 barg/);
    await button(page, 'Copy verbal').click();
    await page.getByRole('status').filter({ hasText: 'Copied to clipboard' }).waitFor();
    assert.match(await page.evaluate(() => navigator.clipboard.readText()), /Test verbal summary/);
    await page.evaluate(() => { window.print = () => { window.diaryPrintRequested = true; }; });
    await button(page, 'Print / PDF').click();
    await page.waitForFunction(() => window.diaryPrintRequested);
    assert.match(await page.locator('#print-area').textContent(), /Synthetic reading 4.5 barg/);
    await page.pdf({ path: path.join(output, 'print-report.pdf'), format: 'A4' });
    await button(page, 'Edit report').click();
    await field(page, 'hse').fill('Test report revision');
    await button(page, 'Save draft').click();
    await page.getByText(/Report versions \(1\)/).waitFor();
    await close(page);
    console.log('PASS night duty, actual log timestamps, selected report text, review gate and version history');

    await nav(page, 'Tasks');
    await openEntry(page, 'Task', 'Test task A');
    await field(page, 'dueDate').fill('03-Nov-2026');
    await field(page, 'priority').selectOption('high');
    await page.getByText('Plan time or record time spent', { exact: true }).click();
    await field(page, 'time').fill('09:00');
    await field(page, 'planMinutes').fill('50');
    await field(page, 'actualMinutes').fill('35');
    await page.locator('#dialog summary').filter({ hasText: /^Subtasks$/ }).click();
    await button(page, 'Add subtask').click();
    await field(page, 'subTitle').fill('Test subtask');
    await page.getByText('Tags, links and attachments', { exact: true }).click();
    await field(page, 'files').setInputFiles({ name: 'fixture.bin', mimeType: 'application/octet-stream', buffer: fixture });
    await saveEntry(page);
    await openEntry(page, 'Task', 'Test task B');
    await field(page, 'date').fill('30-Oct-2026');
    await field(page, 'dueDate').fill('31-Oct-2026');
    await page.locator('#dialog summary').filter({ hasText: /^Reminder$/ }).click();
    await field(page, 'remind').check();
    await saveEntry(page);
    await button(page, 'Board').click();
    await button(page, 'Move up Test task B').click();
    await page.waitForFunction(() => {
      const rows = Diary.storage.read().entries;
      return rows.find(row => row.title === 'Test task B').position < rows.find(row => row.title === 'Test task A').position;
    });
    const target = await page.locator('[data-lane="doing"]').boundingBox();
    await movePointer(page, button(page, 'Drag Test task A'), target.x + 70, target.y + 65);
    await page.locator('[data-lane="doing"]').getByRole('button', { name: 'Test task A', exact: true }).waitFor();
    let data = await stored(page);
    assert.equal(record(data, 'Test task A').dueDate, '2026-11-03');
    assert.equal(record(data, 'Test task A').priority, 'high');
    await button(page, 'Test task A').click();
    assert.deepEqual(await download(page, 'fixture.bin', path.join(output, 'desktop-fixture.bin')), fixture);
    await close(page);
    await page.waitForFunction(() => !!navigator.serviceWorker.controller);
    await nav(page, 'Settings & Backups');
    await page.getByLabel('Browser alerts while the diary is open').check();
    await button(page, 'Save settings').click();
    await page.waitForFunction(async () => {
      const worker = await navigator.serviceWorker.ready;
      return (await worker.getNotifications()).some(item => item.title === 'Diary reminder');
    });
    await nav(page, 'Tasks');
    await button(page, 'Reminders, 1 due').click();
    await button(page, 'Snooze 15 min').click();
    await page.getByText('No reminders due right now.', { exact: true }).waitFor();
    await close(page);
    await page.clock.setFixedTime(new Date(time.getTime() + 16 * 60000));
    await button(page, await page.locator('#reminder-button').getAttribute('aria-label')).click();
    await button(page, 'Acknowledge').click();
    await close(page);
    await page.clock.setFixedTime(time);
    console.log('PASS desktop manual and sideways task movement, deadline/priority preservation, attachment download and reminders');

    await nav(page, 'Daily Diary');
    await openEntry(page, 'Diary Note', 'Test linked note');
    await field(page, 'body').fill('Test note wording with <img src=x>.');
    await field(page, 'scope').selectOption('personal');
    await saveEntry(page);
    await button(page, 'Test linked note').click();
    assert.equal(await page.locator('#dialog img').count(), 0);
    await button(page, 'Draft a linked task').click();
    await field(page, 'title').fill('Test converted task');
    await button(page, 'Save draft').click();
    await page.locator('#dialog').waitFor({ state: 'hidden' });
    await nav(page, 'Settings & Backups');
    await page.locator('#settings-form [name="theme"]').selectOption('dark');
    await button(page, 'Save settings').click();
    await page.waitForFunction(() => document.documentElement.dataset.theme === 'dark');
    await button(page, 'Test converted task').click();
    await button(page, 'Review draft').click();
    await saveEntry(page);
    data = await stored(page);
    const originalNote = record(data, 'Test linked note');
    const linkedTask = record(data, 'Test converted task');
    assert.equal(linkedTask.sourceNoteId, originalNote.id);
    assert.deepEqual(linkedTask.links, [originalNote.id]);
    assert.equal(linkedTask.draft, false);
    await nav(page, 'Daily Diary');
    await button(page, 'Test linked note').click();
    await button(page, 'Draft a linked task').click();
    await page.getByRole('heading', { name: 'Test converted task', exact: true }).waitFor();
    await close(page);
    console.log('PASS diary draft conversion, retained original note and linked task deduplication');

    await nav(page, 'Work Registers');
    await openEntry(page, 'MWR', 'Test maintenance request');
    await field(page, 'body').fill('Fictional description');
    await field(page, 'area').fill('Test area');
    await field(page, 'equipment').fill('DEMO-1');
    await saveEntry(page);
    await button(page, 'Test maintenance request').click();
    await button(page, 'Edit').click();
    await field(page, 'status').selectOption('raised');
    await field(page, 'number').fill('MWR-TEST');
    await field(page, 'raisedDate').fill('01-Nov-2026');
    await field(page, 'followDate').fill('02-Nov-2026');
    await field(page, 'updateText').fill('Test progress note');
    await saveEntry(page);
    await button(page, 'Raised / Follow-up').click();
    await button(page, 'Test maintenance request').click();
    await button(page, 'Edit').click();
    await field(page, 'status').selectOption('closed');
    await button(page, 'Save entry').click();
    await page.getByRole('alert').filter({ hasText: 'closure confirmation' }).waitFor();
    await field(page, 'verifiedBy').fill('Test verifier');
    await field(page, 'closedDate').fill('01-Nov-2026');
    await field(page, 'closeNotes').fill('Test confirmation');
    await saveEntry(page);
    await button(page, 'Contacts & Notebooks').click();
    await button(page, 'New contact').click();
    await field(page, 'name').fill('Test engineer');
    await field(page, 'department').fill('Test department');
    await button(page, 'Save').click();
    await page.locator('#dialog').waitFor({ state: 'hidden' });
    await openEntry(page, 'Follow-up', 'Test delegation');
    await field(page, 'contactId').selectOption({ label: 'Test engineer' });
    await field(page, 'role').selectOption('Day Engineer');
    await field(page, 'status').selectOption('waiting');
    await field(page, 'waitingReason').fill('Fictional waiting reason');
    await saveEntry(page);
    await button(page, 'Delegation & Follow-ups').click();
    await page.locator('main [name="role"]').selectOption('Day Engineer');
    await button(page, 'Test delegation').waitFor();
    console.log('PASS MWR raise and closure, dated update, reusable contact and responsibility filtering');

    await nav(page, 'Planner');
    for (const [title, start, end] of [['Test event one', '09:00', '10:00'], ['Test event two', '09:30', '10:30']]) {
      await openEntry(page, 'Event', title);
      await field(page, 'date').fill('01-Nov-2026');
      await field(page, 'time').fill(start);
      await field(page, 'endTime').fill(end);
      await saveEntry(page);
    }
    await button(page, 'Day').click();
    await page.locator('main [data-navigate-date]').fill('01-Nov-2026');
    await page.locator('main [data-navigate-date]').press('Enter');
    await page.getByText('Overlap', { exact: true }).first().waitFor();
    assert.equal(await page.getByText('Overlap', { exact: true }).count(), 2);
    await button(page, 'Checklists').click();
    await button(page, 'New template').click();
    await field(page, 'name').fill('Test routine');
    await field(page, 'items').fill('Check one\nCheck two');
    await button(page, 'Save').click();
    await page.locator('#dialog').waitFor({ state: 'hidden' });
    await button(page, 'Use on 01-Nov-2026').click();
    await page.getByLabel('Check one', { exact: true }).check();
    await page.waitForFunction(() => Diary.storage.read().checklists[0]?.items[0]?.done);
    await button(page, 'Goals').click();
    await button(page, 'New goal').click();
    await field(page, 'name').fill('Test goal');
    await field(page, 'target').fill('4');
    await field(page, 'unit').fill('sessions');
    await button(page, 'Save').click();
    await page.locator('#dialog').waitFor({ state: 'hidden' });
    await button(page, 'Log progress').click();
    await field(page, 'amount').fill('2');
    await field(page, 'note').fill('Test review note');
    await button(page, 'Save progress').click();
    await page.getByText('2 / 4 sessions · 50%', { exact: true }).waitFor();
    await button(page, 'Search diary').click();
    await page.locator('#search-form [name=area]').fill('Test area');
    await page.locator('#search-form [name=equipment]').fill('DEMO-1');
    await page.locator('#search-form [name=type]').selectOption('mwr');
    await button(page, 'Search').click();
    await button(page, 'Test maintenance request').waitFor();
    await nav(page, 'Reviews');
    await page.getByRole('heading', { name: 'Weekly & Monthly Review' }).waitFor();
    await page.getByText('Work 35 min · Personal 0 min', { exact: true }).waitFor();
    console.log('PASS calendar overlaps, checklists, goal progress, global search and review views');

    await nav(page, 'Today');
    await button(page, 'Open handover').click();
    await button(page, 'Carry to next shift').click();
    assert.equal(await field(page, 'date').inputValue(), '31-Oct-2026');
    assert.equal(await field(page, 'shift').inputValue(), 'Night');
    assert.equal(await field(page, 'toDate').inputValue(), '01-Nov-2026');
    assert.equal(await field(page, 'toShift').inputValue(), 'Evening');
    await page.getByLabel(/Test task A.*In progress/).check();
    await field(page, 'note').fill('Test handover');
    await button(page, 'Save handover').click();
    await page.locator('#dialog').waitFor({ state: 'hidden' });
    const dateField = page.locator('main [data-navigate-date]');
    await dateField.fill('01-Nov-2026');
    await dateField.press('Enter');
    await page.getByText('From 31-Oct-2026 Night', { exact: true }).waitFor();
    assert.equal(record(await stored(page), 'Test task A').dueDate, '2026-11-03');

    await setDuty(page, '02-Nov-2026', 'Off');
    await nav(page, 'Planner');
    await button(page, 'Checklists').click();
    await button(page, 'New template').click();
    await field(page, 'name').fill('Test Off routine');
    await field(page, 'frequency').selectOption('Off');
    await field(page, 'items').fill('Original Off step');
    await button(page, 'Save').click();
    await page.locator('#dialog').waitFor({ state: 'hidden' });
    const offTemplate = page.locator('main .row').filter({ has: page.getByRole('heading', { name: 'Test Off routine', exact: true }) });
    await offTemplate.getByRole('button', { name: 'Use on 02-Nov-2026' }).click();
    await page.getByLabel('Original Off step', { exact: true }).check();
    await page.waitForFunction(() => Diary.storage.read().checklists.find(row => row.shift === 'Off')?.items[0]?.done);
    await offTemplate.getByRole('button', { name: 'Edit', exact: true }).click();
    await field(page, 'items').fill('Updated Off step');
    await button(page, 'Save').click();
    await page.locator('#dialog').waitFor({ state: 'hidden' });
    assert.equal((await stored(page)).checklists.find(row => row.shift === 'Off').items[0].title, 'Original Off step');
    console.log('PASS overnight handover carries links and Off routines keep past completion when edited');

    await nav(page, 'Tasks');
    for (const [title, mode, unit, expected] of [
      ['Test fixed repeat', 'fixed', 'week', '2026-11-07'], ['Test completion repeat', 'completion', 'month', '2026-12-01']
    ]) {
      await openEntry(page, 'Task', title);
      await field(page, 'date').fill('31-Oct-2026');
      await field(page, 'dueDate').fill('31-Oct-2026');
      await page.locator('#dialog summary').filter({ hasText: /^Repeat$/ }).click();
      await field(page, 'repeatMode').selectOption(mode);
      await field(page, 'repeatUnit').selectOption(unit);
      await saveEntry(page);
      const root = record(await stored(page), title);
      assert.equal((await stored(page)).entries.filter(row => row.seriesId === root.id).length, 0);
      const card = page.locator('[data-taskcard="' + root.id + '"]');
      await card.getByRole('button', { name: 'Complete ' + title, exact: true }).click();
      await page.waitForFunction(id => Diary.storage.read().entries.some(row => row.seriesId === id), root.id);
      assert.equal((await stored(page)).entries.find(row => row.seriesId === root.id).dueDate, expected);
      await card.getByRole('button', { name: 'Reopen ' + title, exact: true }).click();
      await card.getByRole('button', { name: 'Complete ' + title, exact: true }).click();
      await card.getByRole('button', { name: 'Reopen ' + title, exact: true }).waitFor();
      assert.equal((await stored(page)).entries.filter(row => row.seriesId === root.id).length, 1);
    }
    console.log('PASS fixed and completion recurrences schedule one successor through the task controls');

    await nav(page, 'Expenses');
    for (const [title, type, value, category] of [
      ['Test lunch', 'expense', '1,000.10', 'Meals'], ['Test tea', 'expense', '0.20', 'meals'],
      ['Test income', 'income', '2500', 'Salary']
    ]) {
      await button(page, 'Add expense').click();
      await field(page, 'type').selectOption(type);
      await field(page, 'amount').fill(value);
      await field(page, 'category').fill(category);
      await field(page, 'title').fill(title);
      await button(page, 'Save transaction').click();
      await page.locator('#dialog').waitFor({ state: 'hidden' });
    }
    await button(page, 'Set budget').click();
    await field(page, 'amount').fill('1500');
    await button(page, 'Save budget').click();
    await page.locator('#dialog').waitFor({ state: 'hidden' });
    await page.locator('[data-action="budget-edit"][data-category]').click();
    await field(page, 'amount').fill('1200');
    await button(page, 'Save budget').click();
    await page.locator('#dialog').waitFor({ state: 'hidden' });
    const totals = await page.evaluate(() => Diary.financeMonth(Diary.storage.read(), '2026-11'));
    assert.equal(totals.expense, 100030);
    assert.equal(totals.remaining, 49970);
    assert.equal(totals.categories[0].budget.amountMinor, 120000);
    await page.locator('#money-filter-form [name=moneyType]').selectOption('expense');
    await button(page, 'Apply filters').click();
    assert.equal(await button(page, 'Test income').count(), 0);
    const csv = (await download(page, 'Export CSV', path.join(output, 'expenses.csv'))).toString();
    assert.match(csv, /"PKR","1000\.10"/);
    assert.doesNotMatch(csv, /Test income/);
    await button(page, 'Clear').click();
    console.log('PASS income, exact PKR totals, budgets, filters and filtered CSV export');

    await nav(page, 'Settings & Backups');
    const backupPath = path.join(output, 'native-backup.json');
    const backup = JSON.parse((await download(page, 'Download JSON backup', backupPath)).toString());
    const files = Object.values(backup.files);
    assert.equal(files.length, 1);
    assert.deepEqual(Buffer.from(files[0].bytes, 'base64'), fixture);
    const xlsx = await download(page, 'Export Excel', path.join(output, 'diary.xlsx'));
    assert.equal(xlsx.readUInt32LE(0), 0x04034b50);
    const corrupt = structuredClone(backup);
    Object.values(corrupt.files)[0].bytes = 'AQIDBAUGBwg=';
    await page.locator('#restore-file').setInputFiles({
      name: 'tampered.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(corrupt))
    });
    await page.getByRole('status').filter({ hasText: 'checksum or size' }).waitFor();
    assert.equal((await stored(page)).rev, backup.data.rev);
    const badAmount = structuredClone(backup);
    badAmount.data.money[0].amountMinor = 0.1;
    await page.locator('#restore-file').setInputFiles({ name: 'invalid-amount.json', mimeType: 'application/json',
      buffer: Buffer.from(JSON.stringify(badAmount)) });
    await page.getByRole('status').filter({ hasText: 'invalid category, type or amount' }).waitFor();
    assert.equal((await stored(page)).rev, backup.data.rev);
    await page.waitForFunction(() => !!navigator.serviceWorker.controller);
    await desktop.setOffline(true);
    await page.reload();
    await page.getByRole('heading', { name: 'Settings & Backups', exact: true }).waitFor();
    assert.equal(await page.locator('html').getAttribute('data-theme'), 'dark');
    await nav(page, 'Tasks');
    await button(page, 'Test task A').click();
    assert.deepEqual(await download(page, 'fixture.bin', path.join(output, 'offline-fixture.bin')), fixture);
    await button(page, 'Edit').click();
    await field(page, 'body').fill('Edited offline');
    await saveEntry(page);
    await button(page, 'Test task B').click();
    await button(page, 'Delete').click();
    await button(page, 'Move to Deleted items').click();
    await page.locator('#dialog').waitFor({ state: 'hidden' });
    await page.reload();
    await button(page, 'Test task A').waitFor();
    data = await stored(page);
    assert.ok(record(data, 'Test task B').deletedAt);
    assert.equal(record(data, 'Test task A').body, 'Edited offline');
    await nav(page, 'Settings & Backups');
    await page.getByText('Test task B', { exact: true }).waitFor();
    await button(page, 'Recover').click();
    await page.waitForFunction(() => !Diary.storage.read().entries.find(row => row.title === 'Test task B').deletedAt);
    await button(page, 'Undo').click();
    await page.waitForFunction(() => !!Diary.storage.read().entries.find(row => row.title === 'Test task B').deletedAt);
    await restore(page, backupPath);
    data = await stored(page);
    assert.ok(record(data, 'Test task B').deletedAt);
    assert.equal(record(data, 'Test task A').body, 'Edited offline');
    await restore(page, backupPath, 'Replace diary');
    data = await stored(page);
    assert.equal(data.reports.length, 1);
    assert.equal(data.reports[0].versions.length, 1);
    assert.equal(record(data, 'Test maintenance request').number, 'MWR-TEST');
    assert.equal(data.handovers.length, 1);
    assert.equal(data.money.length, 3);
    assert.equal(data.budgets.length, 2);
    assert.equal(data.checklists.length, 2);
    assert.equal(record(data, 'Test task B').deletedAt, '');
    assert.equal(record(data, 'Test linked note').id, originalNote.id);
    await page.getByText('Before replace', { exact: true }).waitFor();
    await desktop.setOffline(false);
    console.log('PASS full backup, checksum rejection, offline reload/edit/delete, attachment access and restore checkpoint');

    const second = await open(desktop);
    await nav(page, 'Tasks');
    await nav(second, 'Tasks');
    for (const tab of [page, second]) {
      await button(tab, 'Test task A').click();
      await button(tab, 'Edit').click();
    }
    await field(page, 'body').fill('First tab edit');
    await field(second, 'body').fill('Second tab edit');
    await saveEntry(page);
    await saveEntry(second);
    data = await stored(second);
    assert.equal(record(data, 'Test task A').body, 'First tab edit');
    assert.ok(data.entries.some(row => row.draft && row.body === 'Second tab edit' && row.conflictOf === record(data, 'Test task A').id));
    console.log('PASS simultaneous tabs retain a recoverable conflicting draft');

    const touch = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true,
      deviceScaleFactor: 2, acceptDownloads: true, timezoneId: 'America/Los_Angeles' });
    const phone = await open(touch);
    assert.equal((await stored(phone)).rev, '', 'another profile starts with its own diary');
    await phone.screenshot({ path: path.join(output, 'mobile-home.png') });
    const legacy = await legacyFixture(browser, output, fixture);
    await nav(phone, 'Settings & Backups', true);
    await restore(phone, legacy.json);
    data = await stored(phone);
    assert.deepEqual(data.entries.map(row => row.id), ['v4-a', 'v4-b', 'v4-deleted']);
    assert.equal(data.entries[0].history[0].note, 'Original history note');
    assert.equal(data.entries[0].subtasks[0].id, 'v4-sub');
    assert.equal(data.entries[0].attachments[0].id, 'legacy_file_01');
    assert.equal(data.entries[0].attachments[0].missing, true);
    assert.equal(data.entries[0].priority, 'critical');
    assert.equal(data.entries[0].dueTime, '09:10');
    assert.equal(data.entries[0].mwrStatus, 'raised');
    assert.equal(data.entries[0].handover, 'Original handover text');
    assert.ok(data.entries[2].deletedAt);
    assert.equal(data.roster[0].shift, 'Night');
    assert.equal(data.reports[0].id, '2026-10-31:Night');
    assert.equal(data.reports[0].status, 'ready');
    assert.equal(data.reports[0].incharge, 'Test shift in-charge');
    assert.equal(data.reports[0].sections.verbal, 'Old verbal summary');
    const badZip = await fs.readFile(legacy.zip);
    badZip[30 + badZip.readUInt16LE(26)] ^= 1;
    await phone.locator('#restore-file').setInputFiles({ name: 'damaged.zip', mimeType: 'application/zip', buffer: badZip });
    await phone.getByRole('status').filter({ hasText: 'checksum' }).waitFor();
    assert.equal((await stored(phone)).rev, data.rev);
    await restore(phone, legacy.zip, 'Restore attachments');
    assert.equal((await stored(phone)).entries[0].attachments[0].missing, false);
    await restore(phone, [legacy.json, legacy.zip], 'Merge records');
    assert.equal((await stored(phone)).entries.length, 3);
    await nav(phone, 'Tasks', true);
    await button(phone, 'Board').tap();
    const cdp = await touch.newCDPSession(phone);
    await phone.evaluate(() => {
      const card = document.querySelector('[data-taskcard="v4-b"]');
      window.scrollBy(0, card.getBoundingClientRect().top - 220);
    });
    let from = await button(phone, 'Drag Legacy task A').boundingBox();
    const before = await phone.locator('[data-taskcard="v4-b"]').boundingBox();
    await moveTouch(cdp, from, before.x + 55, before.y + 8);
    await phone.waitForFunction(() => {
      const rows = Diary.storage.read().entries;
      return rows[0].position < rows[1].position;
    });
    from = await button(phone, 'Drag Legacy task A').boundingBox();
    const doing = await phone.locator('[data-lane="doing"]').boundingBox();
    await moveTouch(cdp, from, doing.x + 48, doing.y + 62);
    await phone.waitForFunction(() => Diary.storage.read().entries[0].status === 'doing');
    await phone.locator('[data-lane="doing"]').getByRole('button', { name: 'Legacy task A', exact: true }).tap();
    assert.deepEqual(await download(phone, 'legacy.bin', path.join(output, 'mobile-fixture.bin')), fixture);
    await close(phone);
    await button(phone, 'Move to previous status Legacy task A').tap();
    await phone.waitForFunction(() => Diary.storage.read().entries[0].status === 'todo');
    await phone.screenshot({ path: path.join(output, 'mobile-board.png') });
    assert.deepEqual(errors, []);
    console.log('PASS separate browser profiles, legacy ZIP CRC, attachment byte equality and touch drag');
    console.log(legacy.exact ? 'PASS imported real JSON and ZIP exports produced by the attached Task Desk using fictional records' :
      'PASS imported equivalent Task Desk JSON and stored ZIP test fixtures');
    const v5 = structuredClone(backup.data);
    v5.schemaVersion = 5;
    for (const name of ['handovers', 'money', 'budgets']) delete v5[name];
    const previous = await browser.newContext({ acceptDownloads: true });
    await previous.addInitScript(({ data, files }) => {
      localStorage.setItem('my-shift-life-diary:v5', JSON.stringify(data));
      for (const [id, row] of Object.entries(files)) localStorage.setItem('my-shift-life-diary:v5:diary-files:' + id, row.bytes);
    }, { data: v5, files: backup.files });
    const upgraded = await open(previous);
    assert.equal((await stored(upgraded)).schemaVersion, 6);
    await nav(upgraded, 'Tasks');
    await button(upgraded, 'Test task A').click();
    assert.deepEqual(await download(upgraded, 'fixture.bin', path.join(output, 'upgraded-fixture.bin')), fixture);
    await previous.close();
    console.log('PASS v5 same-origin storage upgrade retains task and attachment bytes');
    await browser.close();
    browser = null;
    const profile = await fs.mkdtemp(path.join(os.tmpdir(), 'shift-life-profile-'));
    let persistent;
    try {
      persistent = await chromium.launchPersistentContext(profile, launch);
      const first = await open(persistent);
      await openEntry(first, 'Task', 'Restart check');
      await saveEntry(first);
      await first.waitForFunction(() => !!navigator.serviceWorker.controller);
      if (process.env.DIARY_VERIFY_UPDATE === '1') {
        const workerPath = path.join(project, source, 'sw.js');
        const script = await fs.readFile(workerPath, 'utf8');
        const newCache = 'shift-life-shell-verification-' + Date.now();
        try {
          await nav(first, 'Settings & Backups');
          await fs.writeFile(workerPath, script.replace(/const CACHE = '[^']+';/, "const CACHE = '" + newCache + "';"));
          await first.evaluate(async () => (await navigator.serviceWorker.getRegistration()).update());
          await button(first, 'Reload with update').click();
          await button(first, 'Reload').click();
          await first.waitForFunction(async cache => (await caches.keys()).includes(cache) &&
            document.querySelector('h1')?.textContent === 'Settings & Backups' && !!window.Diary?.storage?.read()?.rev, newCache);
          assert.equal((await stored(first)).entries[0].title, 'Restart check');
          console.log('PASS service worker app update retains saved records');
        } finally {
          await fs.writeFile(workerPath, script);
        }
      }
      await persistent.close();
      persistent = await chromium.launchPersistentContext(profile, launch);
      await persistent.setOffline(true);
      const reopened = await open(persistent);
      await nav(reopened, 'Tasks');
      await button(reopened, 'Restart check').waitFor();
      assert.equal((await stored(reopened)).entries.length, 1);
      console.log('PASS saved task and offline shell reopen after a complete Chromium restart');
    } finally {
      await persistent?.close();
      await fs.rm(profile, { recursive: true, force: true });
    }
    console.log('Browser evidence written to ' + output);
  } finally {
    await browser?.close();
    host.kill();
  }
}

run().catch(error => { console.error(error); process.exitCode = 1; });
