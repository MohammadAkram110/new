/* Reproduce the exact legacy exporters when DIARY_TASK_DESK names the supplied HTML. */
const fs = require('node:fs/promises');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

const time = Date.parse('2026-10-31T20:15:00Z');
const id = 'legacy_file_01';
const state = {
  schemaVersion: 4,
  tasks: [
    { id: 'v4-a', text: 'Legacy task A', status: 'pending', priority: 'critical', category: 'Work',
      order: 4.5, createdAt: time, updatedAt: time, dueAt: Date.parse('2026-11-03T09:10:00+05:00'),
      dutyDate: '2026-10-31', shift: 'Night', area: 'Ground Floor', equipment: 'DEMO-12', assignedBy: 'Test assigner',
      responsible: 'Test operator', department: 'Test department', contact: 'Test extension',
      mwr: 'MWR-LEGACY', mwrStatus: 'raised', notes: 'Original detail', handover: 'Original handover text',
      closingComment: 'Original closing note', reminderMinutes: 30, seriesId: 'v4-a', occurrence: 0,
      repeat: { every: 1, unit: 'week', from: 'schedule', anchorDay: 3 },
      history: [{ at: time, action: 'Old edit', note: 'Original history note' }],
      subtasks: [{ id: 'v4-sub', text: 'Old checklist item', done: true }] },
    { id: 'v4-b', text: 'Legacy task B', status: 'pending', category: 'Personal', order: -0.5, createdAt: time, updatedAt: time },
    { id: 'v4-deleted', text: 'Legacy deleted task', status: 'completed', order: 5, deleted: true,
      createdAt: time, updatedAt: time, completedAt: time }
  ],
  roster: [{ id: '2026-10-31', date: '2026-10-31', shift: 'Night', note: 'Original roster note', updatedAt: time }],
  reports: [{ id: '2026-10-31:Night', date: '2026-10-31', shift: 'Night', createdAt: time, updatedAt: time, ready: true,
    hse: 'Old HSE point', lab: 'Old lab point', plant1: 'Old plant point', pending: 'Old pending work',
    verbalSummary: 'Old verbal summary', incharge: 'Test shift in-charge', handoverTo: 'Test recipient' }]
};

function storedZip(name, file) {
  let crc = 0xffffffff;
  for (const byte of file) {
    crc ^= byte;
    for (let i = 0; i < 8; i += 1) crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0);
  }
  crc = (crc ^ 0xffffffff) >>> 0;
  const filename = Buffer.from(name, 'utf8');
  const local = Buffer.alloc(30);
  local.writeUInt32LE(0x04034b50, 0);
  local.writeUInt16LE(20, 4);
  local.writeUInt16LE(2048, 6);
  local.writeUInt32LE(crc, 14);
  local.writeUInt32LE(file.length, 18);
  local.writeUInt32LE(file.length, 22);
  local.writeUInt16LE(filename.length, 26);
  const central = Buffer.alloc(46);
  central.writeUInt32LE(0x02014b50, 0);
  central.writeUInt16LE(20, 4);
  central.writeUInt16LE(20, 6);
  central.writeUInt16LE(2048, 8);
  central.writeUInt32LE(crc, 16);
  central.writeUInt32LE(file.length, 20);
  central.writeUInt32LE(file.length, 24);
  central.writeUInt16LE(filename.length, 28);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(1, 8);
  end.writeUInt16LE(1, 10);
  end.writeUInt32LE(central.length + filename.length, 12);
  end.writeUInt32LE(local.length + filename.length + file.length, 16);
  return Buffer.concat([local, filename, file, central, filename, end]);
}

module.exports = async function legacyFixture(browser, output, bytes) {
  const seed = structuredClone(state);
  seed.tasks[0].attachments = [{ id, name: 'legacy.bin', type: 'application/octet-stream',
    size: bytes.length, createdAt: time, uploaded: false }];
  const json = path.join(output, 'Task_Desk_Backup_test.json');
  const zip = path.join(output, 'Task_Desk_Attachments_test.zip');
  const original = process.env.DIARY_TASK_DESK;
  if (!original) {
    await fs.writeFile(json, JSON.stringify(seed));
    await fs.writeFile(zip, storedZip(id + '_legacy.bin', bytes));
    return { json, zip, exact: false };
  }

  const profile = await browser.newContext({ acceptDownloads: true });
  try {
    await profile.route(/^https?:\/\//, route => route.abort());
    const page = await profile.newPage();
    await page.goto(pathToFileURL(path.resolve(original)).href);
    await page.waitForFunction(() => !!window.TaskDesk);
    await page.evaluate(async ({ seed, content, id, time }) => {
      const core = window.TaskDeskCore;
      window.TaskDesk.mutate(() => core.normalizeState(seed), null, false);
      await new Promise((resolve, reject) => {
        const request = indexedDB.open('my-task-desk-files-and-copies', 1);
        request.onupgradeneeded = () => {
          request.result.createObjectStore('files', { keyPath: 'id' });
          request.result.createObjectStore('snapshots', { keyPath: 'id' });
        };
        request.onerror = () => reject(request.error);
        request.onsuccess = () => {
          const db = request.result;
          const tx = db.transaction('files', 'readwrite');
          tx.objectStore('files').put({ id, blob: new Blob([Uint8Array.from(content)]), owner: null, createdAt: time });
          tx.oncomplete = () => { db.close(); resolve(); };
          tx.onabort = () => reject(tx.error);
        };
      });
    }, { seed, content: [...bytes], id, time });
    await page.locator('#backup-open').click();
    for (const [selector, file] of [['#backup-download', json], ['#attachments-download', zip]]) {
      const pending = page.waitForEvent('download');
      await page.locator(selector).click();
      await (await pending).saveAs(file);
    }
  } finally {
    await profile.close();
  }
  return { json, zip, exact: true };
};
