const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const D = require(fs.existsSync(__dirname + '/../public/core.js') ? '../public/core.js' : '../diary/core.js');

const task = (id, date, extra = {}) => ({ id, date, title: id, type: 'task', scope: 'work', status: 'todo', ...extra });

test('Karachi dates, 24-hour time, leap years and month boundaries', () => {
  assert.deepEqual(D.parts('2026-10-31T20:15:00Z'), { date: '2026-11-01', time: '01:15', second: '00' });
  assert.equal(new Date(D.instant('2026-11-01', '06:00')).toISOString(), '2026-11-01T01:00:00.000Z');
  assert.equal(D.formatDate('2024-02-29'), '29-Feb-2024');
  assert.equal(D.parseDate('29-feb-2025'), '');
  assert.equal(D.addMonths('2024-01-31', 1), '2024-02-29');
  assert.equal(D.addMonths('2025-01-31', 1), '2025-02-28');
  assert.equal(D.addMonths('2025-01-31', 2), '2025-03-31');
});

test('night shift uses its starting date through midnight and month end', () => {
  const data = D.empty();
  D.updateDuty(data, '2026-10-31', 'Night', 'D', '', 'Roster entry');
  D.updateDuty(data, '2026-11-01', 'Morning', 'A', '', 'Roster entry');
  const at = wall => D.dutyAt(data.roster, Date.parse(wall));
  assert.equal(at('2026-10-31T20:15:00Z').current.date, '2026-10-31');
  assert.equal(at('2026-10-31T20:15:00Z').next.shift, 'Morning');
  assert.equal(at('2026-11-01T01:00:00Z').current.shift, 'Morning');
  D.swapDuty(data, '2026-10-31', '2026-11-01', 'Test swap');
  assert.equal(data.roster.find(row => row.date === '2026-11-01').shift, 'Night');
  assert.equal(data.dutyHistory.length, 4);
  assert.equal(data.dutyHistory[3].before.shift, 'Morning');
  assert.match(data.dutyHistory[3].reason, /Test swap/);
});

test('fixed 3-, 4- and 6-month tasks advance only on completion and retain the month anchor', () => {
  const data = D.empty();
  for (const interval of [3, 4, 6]) data.entries.push(task('root-' + interval, '2024-01-31', {
    dueDate: '2024-01-31', position: interval, recurrence: { mode: 'fixed', unit: 'month', interval }
  }));
  const done = '2024-05-30T10:00:00Z';
  assert.equal(D.generateRecurrence(data, done), 0);
  for (const row of data.entries) D.setTaskStatus(row, 'done', done);
  assert.equal(D.generateRecurrence(data, done), 3);
  const next = id => data.entries.find(row => row.seriesId === id);
  assert.equal(next('root-3').occurrenceDate, '2024-07-31');
  assert.equal(next('root-4').occurrenceDate, '2024-05-31');
  assert.equal(next('root-6').occurrenceDate, '2024-07-31');
  assert.equal(D.generateRecurrence(data, done), 0);
  const deleted = next('root-3');
  deleted.deletedAt = done;
  D.setTaskStatus(data.entries[0], 'todo', done);
  D.setTaskStatus(data.entries[0], 'done', done);
  assert.equal(D.generateRecurrence(data, done), 0);
  assert.equal(data.entries.filter(row => row.id === deleted.id).length, 1);
  assert.equal(new Set(data.entries.map(row => row.position)).size, data.entries.length);
});

test('completion-based repeat uses Karachi completion date and stays deduplicated', () => {
  const data = D.empty();
  data.entries.push(task('completion', '2023-10-31', {
    dueDate: '2023-10-31', completedAt: '2023-10-30T20:00:00Z', status: 'done',
    subtasks: [{ id: 'check-1', title: 'Check', done: true }],
    recurrence: { mode: 'completion', interval: 4, unit: 'month' }
  }));
  assert.equal(D.generateRecurrence(data, '2023-11-01T00:00:00Z'), 1);
  assert.equal(data.entries[1].dueDate, '2024-02-29');
  assert.equal(data.entries[1].previousOccurrenceId, 'completion');
  assert.equal(data.entries[1].subtasks[0].done, false);
  assert.equal(D.generateRecurrence(data, '2024-01-01T00:00:00Z'), 0);
});

test('manual placement moves sideways without rewriting priority or deadline', () => {
  const a = task('a', '2026-11-01', { position: 1, dueDate: '2026-11-07', priority: 'high' });
  const b = task('b', a.date, { position: 2, dueDate: '2026-11-02', priority: 'low' });
  const c = task('c', a.date, { position: 1, status: 'doing' });
  const list = [a, b, c];
  assert.equal(D.moveTask(list, b.id, 'todo', a.id), true);
  assert.deepEqual([a.position, b.position, c.position], [2, 1, 3]);
  assert.equal(D.moveTask(list, a.id, 'doing', c.id), true);
  D.setTaskStatus(a, 'doing', '2026-11-01T09:00:00Z');
  assert.equal(a.position, 2);
  assert.equal(c.position, 3);
  assert.equal(a.dueDate, '2026-11-07');
  assert.equal(a.priority, 'high');
});

test('calendar projects recurring spans, detects overlaps and keeps one-sided search open', () => {
  const data = D.empty();
  data.entries.push(
    { id: 'event', type: 'event', scope: 'work', title: 'Equipment course', date: '2025-01-31', time: '23:30',
      endDate: '2025-02-01', endTime: '01:00', recurrence: { mode: 'fixed', interval: 1, unit: 'month' } },
    { id: 'appointment', type: 'meeting', scope: 'work', title: 'Equipment meeting', date: '2025-03-01', time: '00:45', endTime: '01:15' },
    task('old', '2015-11-01', { title: 'Equipment inspection', person: 'Test Person' })
  );
  const events = D.eventsIn(data, '2025-03-01', '2025-03-01');
  assert.equal(events.length, 2);
  assert.equal(D.overlaps(events).size, 2);
  assert.equal(D.search(data, { to: '2026-11-01', person: 'test', words: 'equipment inspection' })[0].id, 'old');
});

test('reminders respect overnight quiet hours, snooze, acknowledgement and time changes', () => {
  const data = D.empty();
  data.settings.quietStart = '22:00';
  data.settings.quietEnd = '06:00';
  data.entries.push(task('remind', '2026-10-31', { dueDate: '2026-10-31', dueTime: '21:00', remind: true, remindMinutes: 10 }));
  const quiet = D.instant('2026-11-01', '05:59');
  const audible = D.instant('2026-11-01', '06:00');
  assert.equal(D.reminderRows(data, quiet).length, 0);
  const [item] = D.reminderRows(data, audible);
  assert.equal(item.dueAt, D.instant('2026-10-31', '20:50'));
  data.reminders[item.key] = { snooze: audible + 900000 };
  assert.equal(D.reminderRows(data, audible + 60000).length, 0);
  assert.equal(D.reminderRows(data, audible + 900000).length, 1);
  data.reminders[item.key] = { ack: '2026-11-01T01:00:00Z' };
  assert.equal(D.reminderRows(data, audible + 900000).length, 0);
  data.entries[0].dueTime = '21:30';
  assert.equal(D.reminderRows(data, audible + 900000).length, 1);
});

test('report draft uses only selected text and deduplicates sources and lines', () => {
  const report = { date: '2026-10-31', shift: 'Night', sections: {}, sources: [] };
  const log = { id: 'log-1', title: 'Check 1', body: 'Entered observation', readings: 'Example reading 4.5 barg' };
  assert.equal(D.appendReportSource(report, 'plant1', log), true);
  assert.equal(D.appendReportSource(report, 'pending', log), false);
  assert.equal(D.appendReportSource(report, 'plant2', { ...log, id: 'another' }), false);
  assert.equal(report.sources.length, 1);
  assert.match(D.reportText(report), /Example reading 4.5 barg/);
  assert.equal(report.sections.pending, undefined);
});

test('review uses saved dates and includes historical open MWR age', () => {
  const data = D.empty();
  data.entries.push(task('completed', '2026-10-30', { status: 'done', completedAt: '2026-11-03T10:00:00Z' }),
    task('late', '2026-10-31', { dueDate: '2026-11-02' }),
    task('future', '2026-11-05', { dueDate: '2026-11-10' }),
    { id: 'mwr', date: '2026-11-02', raisedDate: '2026-11-03', closedDate: '2026-11-12', type: 'mwr',
      scope: 'work', status: 'closed', title: 'Closed later' });
  const stats = D.metrics(data, '2026-11-02', '2026-11-08', '2026-11-15');
  assert.deepEqual(stats.completed.map(row => row.id), ['completed']);
  assert.deepEqual(stats.overdue.map(row => row.id), ['late']);
  assert.deepEqual(stats.carried.map(row => row.id), ['completed', 'late']);
  assert.deepEqual(stats.upcoming.map(row => row.id), ['future']);
  assert.equal(stats.mwrs[0].age, 5);
});

test('PKR totals, case-insensitive categories and amounts remaining use integer paisa', () => {
  const data = D.empty();
  const transaction = (date, type, amount, category) => ({ date, type, category, amountMinor: D.parseMoney(amount) });
  data.money.push(
    transaction('2026-11-07', 'expense', '1,000.10', 'Meals'),
    transaction('2026-11-08', 'expense', '0.20', 'meals'),
    transaction('2026-11-08', 'income', '2,500.00', 'Pay'),
    transaction('2026-12-08', 'expense', '50', 'Meals')
  );
  data.budgets.push({ month: '2026-11', category: '', amountMinor: 150000 }, { month: '2026-11', category: 'Meals', amountMinor: 120000 });
  const summary = D.financeMonth(data, '2026-11');
  assert.equal(summary.expense, 100030);
  assert.equal(summary.income, 250000);
  assert.equal(summary.remaining, 49970);
  assert.equal(summary.categories[0].budget.amountMinor - summary.categories[0].spent, 19970);
  assert.equal(D.parseMoney('1,00.09'), null);
  assert.equal(D.parseMoney('1.005'), null);
});

test('night handover follows its starting date and keeps original task deadlines', () => {
  const data = D.empty();
  D.updateDuty(data, '2026-11-07', 'Night', 'D', '', '');
  D.updateDuty(data, '2026-11-08', 'Morning', 'A', '', '');
  assert.equal(D.dutyAt(data.roster, Date.parse('2026-11-07T21:00:00Z')).current.date, '2026-11-07');
  assert.equal(D.nextDutyAfter(data.roster, '2026-11-07', 'Night').date, '2026-11-08');
  const item = task('follow', '2026-11-07', { status: 'waiting', shift: 'Night', dueDate: '2026-11-07' });
  data.entries.push(item);
  data.handovers.push({ date: '2026-11-07', shift: 'Night', toDate: '2026-11-08', toShift: 'Morning', itemIds: [item.id] });
  const [pending] = D.pendingHandover(data, '2026-11-08', 'Morning', { date: '2026-11-08', time: '06:00' });
  assert.equal(pending.row.id, item.id);
  assert.equal(pending.row.dueDate, '2026-11-07');
  assert.equal(pending.transfer.shift, 'Night');
});

test('time blocks can span midnight and reviews use the recorded date and actual minutes', () => {
  const data = D.empty();
  const item = task('plan', '2026-11-07', { time: '23:45', planMinutes: 60, actualMinutes: 35, actualDate: '2026-11-08' });
  data.entries.push(item);
  assert.equal(D.calendarEnd(item), '2026-11-08');
  assert.equal(D.eventsIn(data, '2026-11-08', '2026-11-08')[0].id, 'plan');
  assert.equal(D.metrics(data, '2026-11-08', '2026-11-08', '2026-11-08').time.work, 35);
});
