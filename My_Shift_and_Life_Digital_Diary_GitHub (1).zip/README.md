# My Shift & Life Digital Diary

A browser-only diary for CAN Plant shifts, daily planning and personal expenses. Use the same production link on both devices. Each browser profile keeps its own records and attachment files.

## Try it on your laptop

1. Extract the ZIP. Open a terminal in the extracted project folder, where this README and the `public` folder are.
2. With Python installed, start the static server.

   ```sh
   python3 -m http.server 8000 --bind 127.0.0.1 --directory public
   ```

   On Windows, use `py` if that is your Python command.
3. Open [http://127.0.0.1:8000/](http://127.0.0.1:8000/) in a browser. Add a trial task or use **Settings & Backups → Sample entries**. Keep the terminal open while you use this address.

The app uses HTML, CSS and JavaScript. The `public` folder is ready to serve as delivered.

## Upload to GitHub and connect Vercel

1. Create or open the GitHub repository for the diary. Use **Add file → Upload files**. Upload the extracted project files and folders, keeping `README.md` and `public/` at the repository root. Commit the upload. Keep personal data exports, screenshots and attachments outside the repository. [GitHub upload instructions](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)
2. In Vercel, choose **Add New → Project**, connect GitHub and import the repository. Use these settings. [Vercel build settings](https://vercel.com/docs/builds/configure-a-build)

   | Setting | Value |
   | --- | --- |
   | Framework Preset | **Other** |
   | Root Directory | Repository root, shown as **./** |
   | Build Command | Enable **Override** and leave it empty |
   | Output Directory | **public** |
   | Install Command | Default |
   | Environment Variables | Leave empty |

3. Choose **Deploy**. Copy the production HTTPS address and open it on your phone and laptop. Bookmark that address in your regular browser. Create a test entry, refresh and open it again.
4. For future releases, push the updated source to the same repository and keep the production address. When changing the app code yourself, bump the cache name in `public/sw.js` with each release. A pending app update can be applied from **Settings & Backups → Reload with update**. It also takes over after the old app tabs are closed.

Browser storage is scoped to the website origin and browser profile. A change of scheme, host, port, browser or profile can open a separate diary. Clearing site data or ending a private browsing session can remove records. Your device and browser profile control access. Use a private folder for backups containing plant, personal or financial records. [Browser storage and eviction](https://developer.mozilla.org/en-US/docs/Web/API/Storage_API/Storage_quotas_and_eviction_criteria)

## Use the diary

| Screen | What you can do |
| --- | --- |
| **Today** | See the current and next duty, priorities, tasks, time blocks, routines and pending handover. Add a task, note or expense from the top. |
| **Tasks** | Use List or Board. Search task text, person, area, equipment or MWR. Filter by category, date window, priority, status, area or shift. Use handles or arrow buttons to move tasks. The manual list order is global. The Board uses that order within each status. |
| **Planner** | See days, weeks and months with duties, appointments, deadlines and task time blocks. In a task, open **Plan time or record time spent** to add planned minutes or record actual minutes. Timed overlaps are marked. |
| **Routines** | Open **Planner → Checklists**. Create an everyday template, one for any rostered day, or one for Morning, Evening, Night, Off or Leave. Start it for a date. Changes to a template apply to new checklists. Past checklist steps and completion stay with the date they were recorded. |
| **Daily Diary** | Write work and personal notes, add tags, pin important entries and search dates or keywords. A note can become a linked task after you review it. |
| **Shift Desk** | Enter or swap duties by date. Night duty uses the starting date, including after midnight. Open **Handover** and choose the open items to carry to the next working duty. The transfer links the original items, leaving their deadlines in place. |
| **Reports** | In Shift Desk, save drafts or review and mark a report Ready. Report fields include in-charge, recipient, HSE/SCD, Lab, Plant Highlights 1–3, completed and pending work, and verbal notes. Copy written or verbal text, export text, or use **Print / PDF** and choose **Save as PDF** in the browser. |
| **Work Registers** | Track MWRs, follow-ups, meetings, contacts and notebooks. The task editor also keeps Task Desk’s MWR number and status, duty date, shift, assignment, closing comment and handover fields. |
| **Expenses** | Log income and spending in PKR. Set an overall monthly budget or category budgets. Remaining means the relevant budget minus expenses. Filters apply to the transaction list and its CSV. Month totals use the full month. |
| **Reviews** | See completed and overdue work, open follow-ups, routine steps checked, actual minutes and the selected month’s expense summary. Recorded time uses the date spent on each task. |
| **Settings & Backups** | Switch between light and dark modes, manage drafts and deleted records, and export or restore your diary. |

Complete a repeating task to create its next occurrence. A fixed schedule advances to the next scheduled slot after completion, keeping the calendar pattern. A completion schedule counts from the completion date in Karachi. Short months use their last day. Reopening and completing a task again keeps the existing successor.

## Offline access and reminders

- Open the production link online once. In **Settings & Backups**, check that **App files are ready to open offline**. Reopen the same link on that device when offline. Your edits save in the browser.
- Use the browser’s **Install** or **Add to Home Screen** option when available. **Request persistent storage** asks the browser to retain this site’s data. Availability depends on the browser and device. [Persistent storage](https://developer.mozilla.org/en-US/docs/Web/API/StorageManager/persist)
- Due reminders appear under the bell. You can snooze or acknowledge them. For supported browser alerts, enable them in Settings and grant permission. Quiet hours use Karachi time. An active page checks periodically. A background tab may check late if the browser slows it down. Closing or suspending the page pauses checking.

## Back up, restore or transfer

1. In **Settings & Backups**, select **Download JSON backup**. This includes all diary sections, expense records, budgets, settings, deleted items and available attachment bytes. Use **Export Excel** for a workbook or **Expenses → Export CSV** for the filtered month’s transactions.
2. Open the diary in the destination browser and choose **Restore backup**. Select the JSON. Inspect the counts, file checks and any warnings in the preview.
3. Choose **Merge records** to add records and keep existing matches. Imported tasks keep their relative order after existing tasks. Matches use IDs and the relevant duty, report or budget keys. Merge keeps the current diary’s settings. Choose **Replace diary** to load the backup as the diary for this browser. Replacement requires confirmation when records already exist. The app saves a local checkpoint before applying either method.
4. Open a task, attachment, report and expense after restoring. **Saved copies** lists local checkpoints. Download individual copies you want to keep separately.

New attachments can be up to 15 MiB each. The diary uses IndexedDB to keep records and files. File sizes and checksums are verified during restore. A native backup flags references whose file bytes were missing at export.

### Move records from the supplied Task Desk

1. Open the original Task Desk where your existing records are visible. Use its backup dialog to download the **Task Desk JSON backup**. If it has task attachments, also download its **Task Desk Attachments ZIP**.
2. In this diary, open **Settings & Backups → Restore backup**. Select both files, or select the JSON first and use **Choose matching ZIP** in its preview. If you already imported the JSON, you can choose its ZIP by itself to add the matching files.
3. Review the preview. The importer preserves task IDs, status, category, priority, order, timestamps, repeat settings and IDs, notes, plant and handover fields, subtasks, history and deleted tasks. It also imports roster dates and notes, along with shift report fields, people, and draft or Ready status.
4. Keep the original files. The old JSON stores attachment names and IDs. File bytes transfer only when they are in the matching ZIP. Task Desk’s exporter includes attachments for active tasks, so deleted-task attachments may require the original file. This diary accepts Task Desk’s stored ZIP format up to 100 MB. General ZIP archives use a different format.

The adapter follows the supplied source’s JSON rules for versions 2–4 and the earlier task array format. Verification used the actual supplied HTML to export a version 4 JSON and matching ZIP with fictional tasks and a binary attachment. Task Desk’s internal saved copies, sign-in state and remote reminder settings are outside those exports. To bring over an older saved copy, open it in Task Desk and export that copy. The previous Digital Diary v5 JSON is also accepted. On the same origin, the app copies v5 records and readable local files into the new store on first opening.

## Project files and verification

- `public/` contains the website and app icons. `task-desk.js` and `task-desk-import.js` retain the sample’s validation, recurrence, report formatting and export compatibility. `device-db.js` and `storage.js` handle local records and backups. `sw.js` caches the app files for offline use.
- `tests/` contains verification scripts that use fictional records. Run `node --test tests/core.test.cjs` with Node 22 or later. For browser checks, install Playwright and Chromium in a test environment, then run `node tests/browser.cjs`. It starts the Python server above. Set `DIARY_TASK_DESK` to the original HTML path to verify its actual exporters. Without it, the tests use matching format fixtures.
- Browser verification covers desktop and emulated touch controls, separate profiles, offline reopening and edits, browser restart and app updates, Night duty, handover, routines, recurrence, expense totals, reports, JSON and ZIP validation, file bytes, merge and replace, and Chromium notification registration with permission. Test your own Vercel deployment and physical devices after publishing.
